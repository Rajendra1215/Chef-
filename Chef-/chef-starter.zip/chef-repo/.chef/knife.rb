# See http://docs.chef.io/config_rb_knife.html for more information on knife configuration options

current_dir = File.dirname(__FILE__)
log_level                :info
log_location             STDOUT
node_name                "sairajendra"
client_key               "#{current_dir}/sairajendra.pem"
validation_client_name   "cogent1-validator"
validation_key           "#{current_dir}/cogent1-validator.pem"
chef_server_url          "https://api.chef.io/organizations/cogent1"
cookbook_path            ["#{current_dir}/../cookbooks"]
